import sys
from PyQt5 import QtWidgets as qw
from PyQt5 import QtCore as qc
from switch import *
from Database import *
from request import *

class Switch(qw.QMainWindow):
    def __init__(self):
        super(Switch, self).__init__()
        self.ui = Ui_MainWindow()
        self.request_function = Request(self.ui,self)

        self.ui.setupUi(self) 
        self.ui.pushButton_5.clicked.connect(self.request_function.Refresh)
        self.ui.pushButton_6.clicked.connect(self.request_function.click_accept)
        self.ui.pushButton_4.clicked.connect(self.request_function.click_refuse)


def main():
    app = qw.QApplication(sys.argv)
    switch = Switch()
    switch.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()