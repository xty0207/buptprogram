from PyQt5 import QtCore, QtGui
from switch import *
from Database import *
from PyQt5 import QtWidgets as qw
import LoginFunction as LF
import re

class Request():
    def __init__(self,ui,MainWindow):
        self.database = Database()
        self.ui = ui
        self.MainWindow = MainWindow
    
    def Refresh(self,id_num):
        #清空当前的listWidget
        self.ui.listWidget.clear()
        id_num = 123456

        sql1 = "select * from request where requester = %s"%(id_num)
        requester_info = self.database.cursor.execute(sql1)
        requester_info = self.database.cursor.fetchall()

        sql2 = "select * from request where requested = %s"%(id_num)
        requested_info = self.database.cursor.execute(sql2)
        requested_info = self.database.cursor.fetchall()


        if requester_info == None and requested_info == None:
            qw.QMessageBox.information(self.MainWindow, '消息',"您目前没有请求信息！")

        if requester_info != None:
            for info in requester_info:
                print(info)
                if info[4] == 1:
                    self.ui.listWidget.addItem("您请求获取用户%s的%s,数目为%s,对方已同意！"%(info[1],info[2],info[3]))
                elif info[4] == 2:
                    self.ui.listWidget.addItem("您请求获取用户%s的%s,数目为%s,对方已拒绝！"%(info[1],info[2],info[3]))

        if requested_info != None:
            for info in requested_info:
                if info[4] == 0:
                    self.ui.listWidget.addItem("用户%s请求获取您的%s,数目为%s,请点击同意或拒绝！"%(info[0],info[2],info[3]))

    def click_accept(self,id_num):
        #获取当前选中的行
        id_num = 123456
        row = self.ui.listWidget.currentItem()
        if "点击同意或拒绝" in row.text():
            #获取row.text()中的手机号码
            temp = re.compile(r'\d\d\d\d\d\d\d\d\d\d\d')
            phone_num = temp.search(row.text()).group()
            #获取“您的”之后，“,数目”之前的字符串
            goods = re.findall(r'您的(\w+),',row.text())[0]
            #获取“数目”之后，“,请点击”之前的字符串
            num = re.findall(r'数目为(\d+),',row.text())[0]

            sql = "update request set response = 1 where requester = %s and requested = %s;"%(phone_num,id_num)
            self.database.cursor.execute(sql)
            self.database.conn.commit()
            qw.QMessageBox.information(self.MainWindow, '消息',"您已同意用户%s的请求！"%(phone_num))

    def click_refuse(self,id_num):
        #获取当前选中的行
        id_num = 123456
        row = self.ui.listWidget.currentItem()
        if "点击同意或拒绝" in row.text():
            #获取row.text()中的手机号码
            temp = re.compile(r'\d\d\d\d\d\d\d\d\d\d\d')
            phone_num = temp.search(row.text()).group()
            #获取“您的”之后，“,数目”之前的字符串
            goods = re.findall(r'您的(\w+),',row.text())[0]
            #获取“数目”之后，“,请点击”之前的字符串
            num = re.findall(r'数目为(\d+),',row.text())[0]

            sql = "update request set response = 2 where requester = %s and requested = %s;"%(phone_num,id_num)
            self.database.cursor.execute(sql)
            self.database.conn.commit()

            user_num = self.database.Search_info('num', 'donator_info', 'id', id_num)
            sql = "update donation_info set quantity = quantity + %s where num_to_donator = %s and materials = '%s';"%(num,user_num[0],goods)
            self.database.cursor.execute(sql)
            self.database.conn.commit()
            qw.QMessageBox.information(self.MainWindow, '消息',"您已拒绝用户%s的请求！"%(phone_num))

            







