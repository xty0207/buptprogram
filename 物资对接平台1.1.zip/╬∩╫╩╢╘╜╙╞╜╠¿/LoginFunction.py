from Database import *
from Register_page import *
from RegisterFunction import *
from PyQt5 import QtWidgets as qw
import updatefunction as gl
#from testmain import login_state,user_id

'''login_state=0
user_id='''''

class Login():
    
    
    def __init__(self,ui,MainWindow):
        self.database = Database()
        #self.Register=Register()实例化
        self.login_ui = ui
        self.MainWindow = MainWindow

    def user_login(self):
        #global login_state,user_id
        gl.login_state=0
        gl.user_id=''
        user_name = self.login_ui.UserPhone.text()
        user_password = self.login_ui.Password.text()
        if len(user_name) == 0 or len(user_password) == 0:
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "您的用户名或密码不能为空")
        elif Register(self.login_ui,self).judge_phone(user_name)==False:
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "请输入正确的手机号码")
        elif len(user_password)<6 or len(user_password)>32:
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "您的密码长度需在6-32位之间，请重新输入")
        else:
            try:
                result = self.database.Login(user_name, user_password)
                num = len(result)
                if num == 2:
                    qw.QMessageBox.information(self.MainWindow, '消息',"登陆成功！")
                gl.login_state=1
                gl.user_id=user_name
            except:
                qw.QMessageBox.information(self.MainWindow, '消息',"登陆失败！请重新输入或注册！")
        
"""     def user_register(self):
        user_name = self.login_ui.UserPhone.text()
        user_password = self.login_ui.Password.text()
        if len(user_name) == 0 or len(user_password) == 0:
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "您的用户名或密码不能为空")
        else:
             """


