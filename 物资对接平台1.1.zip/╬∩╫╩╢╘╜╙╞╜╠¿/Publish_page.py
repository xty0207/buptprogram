from PyQt5 import QtCore,QtWidgets


class mainWindow():
    def setup(self, MainWindow):
        MainWindow.setObjectName("PublishWindow")
        MainWindow.resize(624,511)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.username= QtWidgets.QLineEdit(self.centralwidget)
        self.username.setGeometry(QtCore.QRect(240, 100, 200, 50))
        self.userPhone = QtWidgets.QLineEdit(self.centralwidget)
        self.userPhone.setGeometry(QtCore.QRect(240, 160, 200, 50))    
        self.count= QtWidgets.QLineEdit(self.centralwidget)
        self.count.setGeometry(QtCore.QRect(240, 340, 200, 50))
        self.label_1 = QtWidgets.QLabel(self.centralwidget)
        self.label_1.setGeometry(QtCore.QRect(160, 110, 80, 30))
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(160, 170, 80, 30))
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(190, 230, 60, 30))
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(160, 290,80, 30))
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(190, 350, 60, 30))
        self.buttonPublish = QtWidgets.QPushButton(self.centralwidget)
        self.buttonPublish.setGeometry(QtCore.QRect(280, 400,  90, 50))
        self.buttonBack=QtWidgets.QPushButton(self.centralwidget)
        self.buttonBack.setGeometry(QtCore.QRect(100, 50, 60, 30))

        self.comboBoxArea =QtWidgets. QComboBox(self.centralwidget)
        self.comboBoxArea.setObjectName("comboBox")
        #self.centralwidget.addWidget(self.comboBoxArea)
        self.comboBoxArea.move(240, 231)
        # 单个添加条目
        self.comboBoxArea.addItem('请选择地区')
        # 多个添加条目
        self.comboBoxArea.addItems(['北京市','天津市','上海市','重庆市','河北省','山西省','辽宁省','吉林省','黑龙江省','江苏省','浙江省','安徽省','福建省','江西省','山东省','河南省','湖北省','湖南省','广东省','海南省','四川省','贵州省','云南省','陕西省','甘肃省','青海省','台湾省','内蒙古自治区','广西壮族自治区','西藏自治区','宁夏回族自治区','新疆维吾尔自治区','香港特别行政区','澳门特别行政区'])
        # 信号
        #self.comboBoxArea.currentIndexChanged[str].connect(self.print_value) # 条目发生改变，发射信号，传递条目内容
        #self.comboBoxArea.currentIndexChanged[int].connect(self.print_value)  # 条目发生改变，发射信号，传递条目索引
        self.comboBoxGoods =QtWidgets. QComboBox(self.centralwidget)
        self.comboBoxGoods.setObjectName("comboBox1")
        #self.centralwidget.addWidget(self.comboBoxArea)
        self.comboBoxGoods.move(240, 291)
        # 单个添加条目
        self.comboBoxGoods.addItem('请选择物资')
        self.comboBoxGoods.addItem('口罩')
        self.comboBoxGoods.addItem('帐篷')
        # 多个添加条目
        self.comboBoxGoods.addItems(['消毒液', '测温仪','消毒水','矿泉水','急救药品','防护服','压缩干粮','被褥','发电机'])
        MainWindow.setCentralWidget(self.centralwidget)
        self.publish_retranslate(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def publish_retranslate(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("PublishWindow", "发布页面"))
        self.label_1.setText( _translate("PublishWindow", "用户姓名:"))
        self.label_2.setText(_translate("PublishWindow", "联系方式:"))
        self.label_3.setText(_translate("PublishWindow", "地区:"))
        self.label_4.setText(_translate("PublishWindow", "物资名称:"))
        self.label_5.setText(_translate("PublishWindow", "数量:"))
        self.buttonPublish.setText(_translate("PublishWindow", "发布"))
        self.buttonBack.setText(_translate("PublishWindow", "<返回"))


'''if __name__ == "__main__":
    import sys
    #QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)
    app = QtWidgets.QApplication(sys.argv)
    PublishWindow = QtWidgets.QMainWindow()
    ui = mainWindow()
    ui.setup(PublishWindow)
    PublishWindow.show()
    sys.exit(app.exec_())'''
