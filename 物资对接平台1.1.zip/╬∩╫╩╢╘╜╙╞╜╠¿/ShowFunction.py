from Database import *
from Register_page import *
from Publish_page import *
from RegisterFunction import *
from PyQt5 import QtWidgets as qw
import updatefunction as gl
class Show():
    def __init__(self,ui,MainWindow):
        self.database = Database()
        self.show_ui = ui
        self.MainWindow = MainWindow
    def show(self):
        #清空表格
        self.show_ui.tableWidget.clear()
        self.show_ui.comboBox.currentIndexChanged.connect(self.emit_identity1) #当选中下拉框时发射信号与用户交互时，某个条目被选中发出信号，并传递条目的值
        user_area=self.emit_identity1()
        self.show_ui.comboBox_2.currentIndexChanged.connect(self.emit_identity2) #当选中下拉框时发射信号与用户交互时，某个条目被选中发出信号，并传递条目的值
        user_goods=self.emit_identity2()
        #needed_num=self.show_ui.search.text()
        if user_area=='请选择地区':
            user_area=None
        if user_goods=='请选择物资':
            user_goods=None
        #print(user_area,user_goods)
        try:
            info=self.database.Show_goods(10000,1,user_area,user_goods)
            if info==():
                qw.QMessageBox.information(self.MainWindow, '消息',
                                    "抱歉，当前没有您所需物资，您可以选择其他物资重新搜索")
            else:
                x=0
                for i in info:
                    y=0
                    for j in i:
                    #设定指定行和指定列的项为一个QTableWidgetItem实例对象。调用语法如下：
                        self.show_ui.tableWidget.setItem(x, y, QtWidgets.QTableWidgetItem(str(info[x][y])))
                        y = y + 1
                    x = x + 1
        except:
                qw.QMessageBox.information(self.MainWindow, '消息',
                                    "搜索失败，请重试！")
    def emit_identity1(self):  # 发射身份信号
        return self.show_ui.comboBox.currentText()
    def emit_identity2(self):  # 发射身份信号
        return self.show_ui.comboBox_2.currentText()
    def get(self):
        try:
            needed_num=int(self.show_ui.search.text())
            if needed_num == None:
                qw.QMessageBox.information(self.MainWindow, '消息',
                                           "请输入您需要的物资数量")
            self.show_ui.tableWidget.clicked.connect(self.getcontent)
            try:
                requested_id,goods,num=self.getcontent()
                num = int(num)
                print(requested_id,goods,num)
            except:
                qw.QMessageBox.information(self.MainWindow, '消息',
                                    "请选择一个需求")
            if requested_id=='' or goods=='' or num=='':
                qw.QMessageBox.information(self.MainWindow, '消息',
                                        "点击失败，请重新尝试选中你所需物资")
            elif needed_num>num:
                qw.QMessageBox.information(self.MainWindow, '消息',
                                        "当前物资数量不足，请减少您的所需物资数量")
            else:
                try:
                    info=self.database.Search_info('*','request','requester',gl.user_id,only_1 = False)
                    #print(info)
                    target = 0
                    for a_info in info:
                        if a_info!=None and a_info[1]==requested_id and a_info[2]==goods and a_info[3]==needed_num and a_info[4]==0:
                            qw.QMessageBox.information(self.MainWindow, '消息',"您已发布相关请求，请耐心等待")
                            target = 1
                            break
                    if target == 0:
                        self.database.Insert_info('request',(gl.user_id,requested_id,goods,needed_num,0))
                        self.database.Update_info(requested_id,goods,new_quantity=num-needed_num)
                        qw.QMessageBox.information(self.MainWindow, 'Successfully',"已向对方发送请求！")
                except:
                    qw.QMessageBox.information(self.MainWindow, '消息',
                                        "获取失败，请重试")
        except:
            pass
    def getcontent(self):
        try:
            row_index=self.show_ui.tableWidget.currentIndex().row()
            requested_id=self.show_ui.tableWidget.item(row_index,0).text()
            goods=self.show_ui.tableWidget.item(row_index,4).text()
            quantity=self.show_ui.tableWidget.item(row_index,5).text()
            return requested_id,goods,quantity
        except:
            pass