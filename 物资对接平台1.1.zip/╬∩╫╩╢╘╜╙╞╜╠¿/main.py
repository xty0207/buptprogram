from Database import *
from LoginFunction import Login
import LoginFunction
from RegisterFunction import Register
from Register_page import *
from Publish_page import *
from PublishFunction import *
from Switch_page import *
from ShowFunction import *
from Search_page import *
from RequestFunction import *
import updatefunction as gl
import sys
from PyQt5 import QtWidgets as qw
from PyQt5 import QtCore
'''def close_loginwindow(login_state):
    if login_state==1:
       MainWindow.close()
def openpub(id):
    MainWindow = qw.QMainWindow()
    pub_ui=mainWindow()
    PublishFunction=Publi(pub_ui,MainWindow)
    pub_ui.setup(MainWindow)
    pub_ui.buttonPublish.clicked.connect(lambda:PublishFunction.user_update(id))
    MainWindow.show()
def openshow():
    MainWindow = qw.QMainWindow()
    show_ui=Ui_MainWindow()
    ShowFunction=Show(show_ui,MainWindow)
    show_ui.setupUi(MainWindow)
    show_ui.pushButton.clicked.connect(ShowFunction.show)
    MainWindow.show()
def openswitch(login_state,id):
    if login_state==1:
        MainWindow = qw.QMainWindow()
        switch_ui=Ui_MainWindow0()
        switch_ui.setupUi(MainWindow)
        
        switch_ui.pushButton_3.clicked.connect(lambda:openpub(id))#发布
        switch_ui.pushButton_2.clicked.connect(openshow)#搜索
        MainWindow.show()

    
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)# 创建QApplication对象，作为GUI主程序入口
    MainWindow = qw.QMainWindow()
    register_ui=RegisterWindow()
    mylogin=Login(register_ui,MainWindow)
    myregister = Register(register_ui,MainWindow)
    register_ui.setup(MainWindow)
    phone_ID=mylogin.user_id
    #print(phone_ID)
    register_ui.buttonRegister.clicked.connect(myregister.register)
    register_ui.buttonlogin.clicked.connect(mylogin.user_login)
    MainWindow.show()
    
    #register_ui.buttonlogin.clicked.connect(lambda:close_loginwindow(mylogin.login_state))
    register_ui.buttonlogin.clicked.connect(lambda:openswitch(mylogin.login_state,phone_ID))
    
    sys.exit(app.exec_())'''
class Main(qw.QMainWindow):
    #phone_ID=self.mylogin.user_id
    def __init__(self):
        super(Main, self).__init__()
        self.register_ui=RegisterWindow()
        self.mylogin=Login(self.register_ui,self)
        self.myregister = Register(self.register_ui,self)
        self.register_ui.setup(self)
        self.register_ui.buttonRegister.clicked.connect(self.myregister.register)
        self.register_ui.buttonlogin.clicked.connect(self.mylogin.user_login)
        self.register_ui.buttonlogin.clicked.connect(self.close_loginwindow)
        self.register_ui.buttonlogin.clicked.connect(self.openswitch)
        self.switch_window=switchwindow()
    def close_loginwindow(self):
        if gl.login_state==1:
            self.close()
    
    def openswitch(self):
        if gl.login_state==1:
            self.switch_window.show()
class switchwindow(qw.QMainWindow):
    def __init__(self):
        super(switchwindow, self).__init__()     
        self.switch_ui=Ui_MainWindow0()
        self.request_function = Request(self.switch_ui,self)
        '''self.register_ui=RegisterWindow()
        self.mylogin=Login(self.register_ui,self)'''
        self.switch_ui.setupUi(self)
        self.switch_ui.pushButton_3.clicked.connect(self.close_switch)
        self.switch_ui.pushButton_3.clicked.connect(self.open_pub)#发布
        self.switch_ui.pushButton_2.clicked.connect(self.close_switch)
        self.switch_ui.pushButton_2.clicked.connect(self.openshow)#搜索
        
        self.switch_ui.pushButton_5.clicked.connect(lambda:self.request_function.Refresh(gl.user_id))
        self.switch_ui.pushButton_6.clicked.connect(lambda:self.request_function.click_accept(gl.user_id))
        self.switch_ui.pushButton_4.clicked.connect(lambda:self.request_function.click_refuse(gl.user_id))
        self.pub_window=openpub()
        self.search_window=opensearch()
    def close_switch(self):
        qw.QMainWindow().close()
    def open_pub(self):
        self.pub_window.show()
    def openshow(self):
        self.search_window.show()
class openpub(qw.QMainWindow):
    def __init__(self):
        super(openpub, self).__init__()     
        self.pub_ui=mainWindow()
        '''self.register_ui=RegisterWindow()
        self.mylogin=Login(self.register_ui,self)'''
        self.PublishFunction=Publi(self.pub_ui,self)
        self.pub_ui.setup(self)
        
        self.pub_ui.buttonPublish.clicked.connect(lambda:self.PublishFunction.user_update(gl.user_id))
        self.pub_ui.buttonBack.clicked.connect(self.close_pub)
        #self.pub_ui.buttonBack.clicked.connect(self.openswitch)
        #self.back_switch=switchwindow()
    '''def openswitch(self):
        self.switch_ui=Ui_MainWindow0()
        self.switch_ui.setupUi(self)'''
    def close_pub(self):
        self.close()
class opensearch(qw.QMainWindow):
    def __init__(self):
        super(opensearch, self).__init__()
        self.show_ui=Ui_MainWindow()
        self.ShowFunction=Show(self.show_ui,self)
        self.show_ui.setupUi(self)
        self.show_ui.pushButton.clicked.connect(self.ShowFunction.show)
        self.show_ui.buttonBack.clicked.connect(self.close_search)
        self.show_ui.pushButton1.clicked.connect(self.ShowFunction.get)
    def close_search(self):
        self.close() 
#global login_state,user_id 

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)# 创建QApplication对象，作为GUI主程序入口
    '''login_state=0
    user_id='''''
    #global login_state,user_id
    window=Main()
    window.show()
    sys.exit(app.exec_())
    