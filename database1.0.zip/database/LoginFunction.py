from Database import *
from register_page1 import *
from PyQt5 import QtWidgets as qw
import re


class Login():
    def __init__(self,ui,MainWindow):
        self.database = Database()
        self.login_ui = ui
        self.MainWindow = MainWindow

    def user_login(self):
        user_name = self.login_ui.UserPhone.text()
        user_password = self.login_ui.Password.text()
        if len(user_name) == 0 or len(user_password) == 0:
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "您的用户名或密码不能为空")
        else:
            try:
                result = self.database.Login(user_name, user_password)
                num = len(result)
                assert num == 2
                qw.QMessageBox.information(self.MainWindow, '消息',"登陆成功！")
                #self.login_ui.close()

            except:
                qw.QMessageBox.information(self.MainWindow, '消息',"登陆失败！请重新输入或注册！")

    def user_register(self):
        user_name = self.login_ui.UserPhone.text()
        user_password = self.login_ui.Password.text()
        if len(user_name) == 0 or len(user_password) == 0:
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "您的用户名或密码不能为空")

        elif self.database.Search_info('id', 'account', 'id', user_name) != None:
            qw.QMessageBox.information(self.MainWindow, '消息',"此账号已存在！")

        elif self.judge_phone(user_name) == False:
            qw.QMessageBox.information(self.MainWindow, '消息',"请输入正确的手机号码！")

        elif len(user_password) > 32 or len(user_password) < 6:
            qw.QMessageBox.information(self.MainWindow, '消息',"密码长度必须在6-32位之间！")

        else:
            try:
                info = tuple([user_name, user_password])
                self.database.Insert_info('account',info)
                qw.QMessageBox.information(self.MainWindow, '消息',"注册成功！")
            except:
                qw.QMessageBox.information(self.MainWindow, '消息',"注册失败！请重试！")

            


    def judge_phone(self,tel):
        tel = str(tel)
        ret = re.match(r'^(13[0-9]|14[0|5|6|7|9]|15[0|1|2|3|5|6|7|8|9]|'
                            r'16[2|5|6|7]|17[0|1|2|3|5|6|7|8]|18[0-9]|'
                            r'19[1|3|5|6|7|8|9])\d{8}$', tel)
        if ret:
            return True
        else:
            return False