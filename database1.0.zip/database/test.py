from Database import *
from LoginFunction import Login
from register_page1 import *
import sys
from PyQt5 import QtWidgets as qw
from PyQt5 import QtCore


class First(qw.QMainWindow):
    def __init__(self):
        super(First,self).__init__()
        
        self.login_ui = RegisterWindow()
        self.loginfunction = Login(self.login_ui,self)

        self.login_ui.setup(self)
        self.login_ui.buttonlogin.clicked.connect(self.loginfunction.user_login)
        self.login_ui.buttonRegister.clicked.connect(self.loginfunction.user_register)


def main():
    #QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)
    app = qw.QApplication(sys.argv)
    first = First()
    first.show()
    sys.exit(app.exec_())
if __name__ == '__main__':
    main()

