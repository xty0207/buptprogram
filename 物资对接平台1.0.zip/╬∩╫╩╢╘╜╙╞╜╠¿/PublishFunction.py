from Database import *
from Register_page import *
from Publish_page import *
from RegisterFunction import *
from PyQt5 import QtWidgets as qw
class Publi():
    def __init__(self,ui,MainWindow):
        self.database = Database()
        self.pub_ui = ui
        self.MainWindow = MainWindow
    def user_update(self,id_num):
        name=self.pub_ui.username.text()
        phone=self.pub_ui.userPhone.text()
        quantity=self.pub_ui.count.text()
        #print((name,phone,num,id_num))
        #self.pub_ui.comboBoxArea.setCurrentIndex(0)  #设置默认值 为空
        #self.pub_ui.comboBoxGoods.setCurrentIndex(0)
        self.pub_ui.comboBoxArea.currentIndexChanged.connect(self.emit_identity1) #当选中下拉框时发射信号与用户交互时，某个条目被选中发出信号，并传递条目的值
        user_area=self.emit_identity1()
        #print(user_area)
        self.pub_ui.comboBoxGoods.currentIndexChanged.connect(self.emit_identity2)
        user_goods=self.emit_identity2()
        #print(id_num)
        if len(name) == 0 or len(phone) == 0:
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "您的用户姓名或联系方式不能为空")
        elif user_area=='请选择地区' or user_goods=='请选择物资' :
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "请选择地区或物资种类")
        elif quantity==0 or len(quantity)==0:
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "请输入正确的物资数目")
        elif Register(self.pub_ui,self).judge_phone(phone)==False:
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "请输入正确的手机号码")
        elif id_num=='':
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "请传入正确的ID")
        else:
            try:
                #查询表中是否有该用户
                phone_num = self.database.Search_info('phone_num', 'donator_info', 'phone_num', phone,'id',id_num)
                #print((list_num1,list_num2))
                if phone_num != None:
                    #如果在donator_info表中有id和phone_num相同的记录，则直接插入信息到donation_info表中
                    print("donator_info表中已有该用户：id = %s,phone_num = %s" % (id_num, phone))
                    num = self.database.Search_info('num','donator_info','id',id_num,'phone_num',phone)
                    donationinfo=(num[0],user_goods,quantity)
                    self.database.Insert_info('donation_info',donationinfo)
                else:
                    print("向donator_info表中插入新用户：id = %s,phone_num = %s" % (id_num, phone))
                    donatorinfo = (0,id_num,name,user_area,phone)
                    self.database.Insert_info('donator_info',donatorinfo)
                    donatornum=self.database.Search_info('num','donator_info','id',id_num,'phone_num',phone)
                    #print(donatornum)
                    donationinfo=(donatornum[0],user_goods,quantity)
                    print("向donation_info表中插入数据,物品为：%s,数量为：%s" % (user_goods,quantity))
                    self.database.Insert_info('donation_info',donationinfo)
                #self.database.__del__()
                qw.QMessageBox.information(self.MainWindow, 'Successfully',"发布成功！")

            except:
                qw.QMessageBox.information(self.MainWindow, '消息',"发布失败，请重新发布！")
        
    def emit_identity1(self):  # 发射身份信号
        return self.pub_ui.comboBoxArea.currentText()
    def emit_identity2(self):  # 发射身份信号
        return self.pub_ui.comboBoxGoods.currentText()


