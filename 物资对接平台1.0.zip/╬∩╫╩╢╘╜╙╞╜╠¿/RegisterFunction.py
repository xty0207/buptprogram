from pymysql import *
import pymysql
from PyQt5.QtSql import QSqlDatabase
from Database import *
from Register_page import *
from PyQt5 import QtWidgets as qw
import re


class Register():
    def __init__(self,ui,MainWindow):
        self.database = Database()
        self.register_ui = ui
        self.MainWindow = MainWindow
        
    def judge_phone(self,tel):
        tel =str(tel)
        ret =re.match(r'^(13[0-9]|[14[0|5|6|7|9]|15[0|1|2|3|5|6|7|8|9]|'
                           r'16[2|5|6|7]|17[0|1|2|3|5|6|7|8]|18[0-9]|'
                           r'19[1|3|5|6|7|8/9])\d{8}$' ,tel)
        if ret:
            return True
        else:
            return False
    '''def ConnectToDatabase(self):
        try:
            conn = pymysql.connect(host='test123456.mysql.rds.aliyuncs.com',     
                        port=3306,
                        user='user1',
                        passwd='123456Aa',
                        db='thedatabase')
            cursor = conn.cursor()
            print("连接成功")
        except:
            print("连接失败")'''
    def register(self):
        #self.ConnectToDatabase()
        #id_num=self.register_ui.UserPhone.text()
        data = (self.register_ui.UserPhone.text(), self.register_ui.Password.text())
        
        
        
        if data==('',''):
            qw.QMessageBox.information(self.MainWindow, 'Warning!', '注册信息不能为空'.format(self.register_ui.UserPhone.text()))
        elif self.judge_phone(self.register_ui.UserPhone.text())==False:
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "请输入正确的手机号码")
        elif len(self.register_ui.Password.text())<6 or len(self.register_ui.Password.text())>32:
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "您的密码长度需在6-32位之间，请重新输入")
        elif self.database.Search_info('id','account','id',self.register_ui.UserPhone.text()):
            qw.QMessageBox.information(self.MainWindow, '消息',
                                    "该账户已存在，请登录")
        else:
            self.database.Register(self.register_ui.UserPhone.text(),self.register_ui.Password.text())
            #cursor.execute(sql)
            #conn.commit()
            #cursor.close()
            #conn.close()
            #self.database.__del__()
            qw.QMessageBox.information(self.MainWindow, 'Successfully', '注册成功'.format(self.register_ui.UserPhone.text()))
           


    
'''import ctypes
ctypes.windll.LoadLibrary('C:\Program Files\MySQL\MySQL Server 5.7\lib\libmysql.dll')

db = QSqlDatabase.addDatabase('QMYSQL')
db.setHostName('test123456.mysql.rds.aliyuncs.com')
db.setPort(3306)
db.setDatabaseName('thedatabase')
db.setUserName('user1')
db.setPassword('123456Aa')
if db.open():
    print("连接成功")
else:
    print("连接失败")
from PyQt5.QtSql import QSqlDatabase
print(QSqlDatabase.drivers())'''

