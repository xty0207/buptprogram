#此文件用于声明全局变量
login_state=0
user_id=''